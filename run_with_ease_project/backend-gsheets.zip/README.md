Create a Google Sheet, replace YOUR_SHEET_ID in Code.gs, deploy as Web App (Anyone, even anonymous) and use the URL as POST endpoint.
