Setup: import db.sql into your MySQL database; upload PHP files to hosting; update DB credentials in submit_booking.php and admin_view.php
