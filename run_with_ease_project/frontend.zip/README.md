Frontend single-file app. Open index.html in a browser to preview.
